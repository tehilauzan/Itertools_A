<div dir="rtl" lang="he">

# איטרטורים - שלב ב


בשלב ב עליכם לכתוב מימוש מלא של המחלקות - 
range, accumulate, filterfalse, compress.

המימוש צריך לעבור את כל הבדיקות - שלכם ושלנו.

אנחנו מריצים את הפקודה הבאה:

<div dir='ltr'>

	make test && ./test

</div>
</div>
